import { DAILY_TICKETS_PER_DAY } from "@drawing-app/api/client";
import { expect, test, type Page } from "@playwright/test";
import { strings } from "../src/i18n/strings/index.ts";
import { PALM_CONTACT_PX } from "../src/sticker-creation/canvas/gestures.ts";
import {
  correctPostStroke,
  transferStrokeAttributes,
  type PostCorrectionInput,
} from "../src/sticker-creation/canvas/post-correction/core.ts";
import { FIRST_POST_CORRECTION } from "../src/sticker-creation/canvas/post-correction/settings.ts";
import { canvas, chooseLanguage, drawKeyName, openSettings, say, signIn } from "./helpers.ts";
import { ipad } from "./ipad.ts";
import {
  along,
  at,
  FINGERTIP,
  hand,
  inkAt,
  inkedPixels,
  inkReach,
  inkShows,
  middle,
  pencil,
  penStroke,
  touchStroke,
  type Box,
  type Hand,
} from "./pen.ts";

const { stickerBoard, stickerCreation } = strings;
const language = "en";

declare global {
  interface Window {
    recordCorrectionResponse: (response: unknown) => Promise<void>;
  }
}

// An iPad in portrait, the Pencil's own device.
test.use(ipad);

/** Signs someone new in and opens a fresh sheet; resolves with the paper's box on screen. */
async function openSheet(page: Page, who: string) {
  await signIn(page, who, language);
  await page.getByRole("button", { name: drawKeyName(language, DAILY_TICKETS_PER_DAY) }).click();
  // The sheet takes ink once its ticket is spent, which the timer's first-visit note marks.
  await expect(
    page.getByText(say(stickerCreation.timer.note.startsWhenYouDraw, language)).first(),
  ).toBeVisible();
  const sheet = canvas(page, language);
  // Waits until nothing covers the paper, as the suite's own strokes do.
  await sheet.hover();
  const box = await sheet.boundingBox();
  if (!box) throw new Error("The sheet isn't on screen");
  return box;
}

const undo = (page: Page) =>
  page.getByRole("button", { name: say(stickerCreation.history.undo, language) });
const pencilOnlyTile = (page: Page) =>
  page.getByRole("button", { name: say(stickerCreation.tools.pencilOnly, language) });

/** Exact committed pixel comparison, kept inside the browser to avoid transferring image data. */
async function committedInkDigest(page: Page) {
  return page.locator(".ink-layers canvas").evaluateAll(async (canvases) => {
    return Promise.all(
      canvases.map(async (element) => {
        if (!(element instanceof HTMLCanvasElement)) throw new Error("The layer is not a canvas");
        const canvas = element;
        if (canvas.width === 0 || canvas.height === 0) return `${canvas.width}x${canvas.height}`;
        const context = canvas.getContext("2d");
        if (!context) throw new Error("The committed layer has no drawing context");
        const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
        const digest = await crypto.subtle.digest("SHA-256", pixels);
        return Array.from(new Uint8Array(digest), (byte) =>
          byte.toString(16).padStart(2, "0"),
        ).join("");
      }),
    );
  });
}

/** Two fingertips land together near the sheet's foot, and lift. */
async function twoFingerTap(fingers: Hand, box: Box) {
  const tap = [at(box, 0.3, 0.85), at(box, 0.45, 0.85)].map((point, i) => ({
    ...point,
    id: 10 + i,
    radius: FINGERTIP,
  }));
  await fingers.down(tap);
  await fingers.up();
}

test("post correction preserves every output bit across browser engines", async ({ page }, testInfo) => {
  const bits = (values: readonly number[]) =>
    values.map((value) => {
      const bytes = Buffer.alloc(8);
      bytes.writeDoubleBE(value);
      return bytes.toString("hex");
    });
  const cases = [0.1, 1].map((pressure) => {
    const positions = [[0, 0], [1, 0.3], [2, 1], [3, -0.2], [4, 0], [5, 2]];
    const packets = positions.map(([x, y], index) => ({
      x: x * 0.2,
      y: y * 0.2,
      pressure,
      t: 100 + index * 10,
      phase: (index === 0 ? 2 : index === positions.length - 1 ? 3 : 1) as 1 | 2 | 3,
    }));
    const input: PostCorrectionInput = {
      packets,
      renderedPoints: packets.flatMap((packet, index) => [packet.x, packet.y, index + 1, index * 10]),
      settings: { ...FIRST_POST_CORRECTION, strength: 1 },
      magnificationFraction: 1,
      brushSize: 29.5,
      pointerType: "pen",
      stabilization: 20,
    };
    const expected = correctPostStroke(input).points;
    const geometry = Array.from({ length: expected.length / 4 }, (_, index) => ({
      x: expected[index * 4],
      y: expected[index * 4 + 1],
    }));
    return {
      pressure,
      input,
      geometry,
      expected,
      expectedBits: bits(expected),
      expectedTransferBits: bits(transferStrokeAttributes(geometry, input.renderedPoints)),
    };
  });
  expect(cases[0].expected.slice(0, 4)).toEqual([0, 0, 1, 0]);
  expect(cases[1].expected[0]).toBeGreaterThan(0);
  expect(cases[0].expected).not.toEqual(cases[1].expected);
  for (const c of cases) expect(c.expected.slice(-4)).toEqual([1, 0.4, 6, 50]);

  await page.goto("/");
  const observed = await page.evaluate(async (inputs) => {
    // Vite serves the production module. Only test inputs and bit encoding are repeated here.
    const modulePath = "/src/sticker-creation/canvas/post-correction/core.ts";
    const correction = (await import(modulePath)) as {
      correctPostStroke: typeof correctPostStroke;
      transferStrokeAttributes: typeof transferStrokeAttributes;
    };
    const bits = (values: readonly number[]) =>
      values.map((value) => {
        const bytes = new DataView(new ArrayBuffer(8));
        bytes.setFloat64(0, value);
        return Array.from(new Uint8Array(bytes.buffer), (byte) =>
          byte.toString(16).padStart(2, "0"),
        ).join("");
      });
    return inputs.map(({ input, geometry }) => ({
      points: bits(correction.correctPostStroke(input).points),
      transferred: bits(correction.transferStrokeAttributes(geometry, input.renderedPoints)),
    }));
  }, cases.map(({ input, geometry }) => ({ input, geometry })));
  await testInfo.attach("cross-engine-correction.json", {
    body: JSON.stringify({ cases, observed }, null, 2),
    contentType: "application/json",
  });
  // This checks cross-engine consistency, separately from the native arithmetic comparisons.
  expect(observed).toEqual(cases.map((c) => ({ points: c.expectedBits, transferred: c.expectedTransferBits })));
});

test("a pen's first stroke brings the Pencil only tile; fingers then only tap, until the tile lets them draw", async ({
  page,
}) => {
  const box = await openSheet(page, "pencil-only");
  await expect(pencilOnlyTile(page)).toHaveCount(0);
  const pen = await pencil(page);
  const penRow = along(box, 0.2, 0.1, 0.4);
  await penStroke(page, pen, penRow, () => 0.5);
  await expect(undo(page)).toBeEnabled();
  await expect(pencilOnlyTile(page)).toHaveAttribute("aria-pressed", "true");

  const fingers = await hand(page);
  const fingerRow = along(box, 0.5, 0.6, 0.9);
  await touchStroke(page, fingers, fingerRow, FINGERTIP);
  expect(await inkAt(page, middle(fingerRow))).toBe(0);
  // Fingers still tap: two take the pen's stroke back.
  await twoFingerTap(fingers, box);
  await expect.poll(() => inkAt(page, middle(penRow))).toBe(0);

  await pencilOnlyTile(page).click();
  await expect(pencilOnlyTile(page)).toHaveAttribute("aria-pressed", "false");
  await touchStroke(page, fingers, fingerRow, FINGERTIP);
  expect(await inkAt(page, middle(fingerRow))).toBeGreaterThan(0);
});

test("a hovering pen rings where it will land, as wide as the stroke it draws, and the ring goes as it lands or leaves", async ({
  page,
}) => {
  // Off draws the brush's own width, so the stroke under the ring has one width to match.
  await page.addInitScript(() => localStorage.setItem("draw.penPressure", "off"));
  const box = await openSheet(page, "hover");
  const pen = await pencil(page);
  const ring = page.locator(".nib-ring");
  const row = along(box, 0.4, 0.2, 0.7);
  await pen.hover(row[0]);
  await expect(ring).toBeVisible();
  const shown = await ring.boundingBox();
  if (!shown) throw new Error("The ring has no box");
  expect(Math.abs(shown.x + shown.width / 2 - row[0].x)).toBeLessThan(1.5);
  expect(Math.abs(shown.y + shown.height / 2 - row[0].y)).toBeLessThan(1.5);

  // Pressed ever harder, a stroke under Off keeps one width: the ring's.
  await penStroke(page, pen, row, (i) => 0.1 + (0.9 * i) / row.length, 40);
  await expect(ring).toBeHidden();
  const early = await inkAt(page, row[8]);
  const late = await inkAt(page, row[row.length - 4]);
  expect(Math.abs(early - late)).toBeLessThan(1);
  expect(Math.abs(late - shown.width)).toBeLessThan(2);

  await pen.hover(at(box, 0.5, 0.7));
  await expect(ring).toBeVisible();
  // Above the paper, over the top bar.
  await pen.hover({ x: box.x + 30, y: box.y - 30 });
  await expect(ring).toBeHidden();
});

test("pen pressure: a pen whose pressure never moves draws by speed; then strokes widen as they press harder, and start as light as they land", async ({
  page,
}) => {
  const box = await openSheet(page, "pressure");
  const pen = await pencil(page);
  // The page's first strokes, at one pressure: a quick one draws thinner than a slow one.
  const slow = along(box, 0.15, 0.1, 0.4);
  const quick = along(box, 0.15, 0.6, 0.9);
  await penStroke(page, pen, slow, () => 0.5, 60);
  await penStroke(page, pen, quick, () => 0.5, 0);
  await inkShows(page, middle(slow), middle(quick));
  expect(await inkAt(page, middle(quick))).toBeLessThan(await inkAt(page, middle(slow)));

  // Pressure that moves sets the width: wider where it's pressed harder.
  const rising = along(box, 0.35, 0.1, 0.9);
  await penStroke(page, pen, rising, (i) => 0.1 + (0.9 * i) / rising.length);
  await inkShows(page, rising[4], rising[rising.length - 4]);
  expect(await inkAt(page, rising[4])).toBeLessThan(await inkAt(page, rising[rising.length - 4]));

  // From now on a stroke starts at its first sample's width: a light one starts thin.
  const light = along(box, 0.6, 0.1, 0.4);
  const firm = along(box, 0.6, 0.6, 0.9);
  await penStroke(page, pen, light, () => 0.1);
  await penStroke(page, pen, firm, () => 0.9);
  await inkShows(page, light[2], firm[2]);
  expect(await inkAt(page, light[2])).toBeLessThan(await inkAt(page, firm[2]));
});

test("at Smooth, a pen's line trails its nib, stays still without new packets, and finishes on release", async ({
  page,
}) => {
  const box = await openSheet(page, "smooth-pen");
  const smoothing = page.getByRole("button", {
    name: say(stickerCreation.tools.smoothing, language),
  });
  await smoothing.click();
  await page
    .getByRole("slider", { name: say(stickerCreation.tools.smoothing, language), exact: true })
    .fill("100");
  await smoothing.click();
  await expect(smoothing).toHaveAttribute("aria-expanded", "false");

  const pen = await pencil(page);
  const row = along(box, 0.5, 0.1, 0.6, 30);
  const nib = row[row.length - 1];
  const t0 = Date.now();
  await pen.down(row[0], 0.5, t0);
  for (let i = 1; i < row.length; i++) {
    await pen.move(row[i], 0.5, t0 + i * 16);
    await page.waitForTimeout(16);
  }
  // Moving, the ink stops short of the nib: nothing is drawn ahead of the line.
  expect((await inkReach(page, nib.y)) ?? row[0].x).toBeLessThan(nib.x - 1);
  // Frames alone do not feed a packet-count filter or move its provisional curve.
  await page.waitForTimeout(100);
  const paused = await inkReach(page, nib.y);
  expect(paused).not.toBeNull();
  if (paused === null) throw new Error("The stabilized stroke did not paint any ink");
  await page.waitForTimeout(400);
  expect(await inkReach(page, nib.y)).toBe(paused);
  await pen.up(nib, t0 + row.length * 16);
  // The queue's terminal outputs extend the stroke; they need not snap to the raw nib.
  expect(await inkReach(page, nib.y)).toBeGreaterThan(paused);
  await expect(undo(page)).toBeEnabled();
});

test("post correction runs after pen lift and commits one replayable stroke", async ({
  page,
}, testInfo) => {
  const workerResponses: unknown[] = [];
  await page.exposeFunction("recordCorrectionResponse", (response: unknown) => {
    workerResponses.push(response);
  });
  await page.addInitScript(() => {
    const OriginalWorker = window.Worker;
    window.Worker = class extends OriginalWorker {
      constructor(url: string | URL, options?: WorkerOptions) {
        super(url, options);
        if (String(url).includes("post-correction"))
          this.addEventListener("message", (event) => {
            void window.recordCorrectionResponse(event.data);
          });
      }
    };
  });
  const box = await openSheet(page, "post-correction");
  const smoothing = page.getByRole("button", {
    name: say(stickerCreation.tools.smoothing, language),
    exact: true,
  });
  await smoothing.click();
  await page
    .getByRole("slider", { name: say(stickerCreation.tools.smoothing, language), exact: true })
    .fill("0");
  const post = page.getByRole("slider", {
    name: say(stickerCreation.smoothingBar.postCorrection, language),
    exact: true,
  });
  await post.fill("40");
  await page
    .getByRole("switch", { name: say(stickerCreation.smoothingBar.adjustBySpeed, language) })
    .check();
  await page.screenshot({
    path: testInfo.outputPath("controls-en-ipad.png"),
  });
  await smoothing.click();
  const pen = await pencil(page);
  const row = Array.from({ length: 60 }, (_, i) =>
    at(box, 0.15 + (0.65 * i) / 59, 0.42 + 0.1 * Math.sin(i / 8) + 0.01 * Math.sin(i * 2)),
  );
  await penStroke(page, pen, row, (i) => 0.3 + (0.4 * i) / 59, 8);
  await expect
    .poll(() =>
      workerResponses.some((response) => {
        if (!response || typeof response !== "object") return false;
        return "points" in response || "result" in response;
      }),
    )
    .toBe(true);
  await expect(undo(page)).toBeEnabled();
  await expect(
    page.getByText(say(stickerCreation.layers.postCorrectionFailed, language)),
  ).toHaveCount(0);
  const painted = await inkedPixels(page, ".ink-layers");
  expect(painted).toBeGreaterThan(0);
  const paintedDigest = await committedInkDigest(page);
  await undo(page).click();
  await expect.poll(() => inkedPixels(page, ".ink-layers")).toBe(0);
  await page.getByRole("button", { name: say(stickerCreation.history.redo, language) }).click();
  await expect.poll(() => inkedPixels(page, ".ink-layers")).toBe(painted);
  expect(await committedInkDigest(page)).toEqual(paintedDigest);

  // A corrected eraser must remove committed pixels and replay that exact removal.
  await page
    .getByRole("button", { name: say(stickerCreation.tools.eraser, language), exact: true })
    .click();
  await penStroke(page, pen, along(box, 0.44, 0.12, 0.84, 40), () => 0.8, 8);
  await expect
    .poll(
      () =>
        workerResponses.filter(
          (response) =>
            response &&
            typeof response === "object" &&
            "type" in response &&
            response.type === "complete",
        ).length,
    )
    .toBe(2);
  await expect.poll(() => inkedPixels(page, ".ink-layers")).toBeLessThan(painted);
  const erasedDigest = await committedInkDigest(page);
  await undo(page).click();
  await expect.poll(() => committedInkDigest(page)).toEqual(paintedDigest);
  await page.getByRole("button", { name: say(stickerCreation.history.redo, language) }).click();
  await expect.poll(() => committedInkDigest(page)).toEqual(erasedDigest);
  await smoothing.click();
  await expect(post).toHaveValue("40");
  await expect(
    page.getByRole("switch", { name: say(stickerCreation.smoothingBar.adjustBySpeed, language) }),
  ).toBeChecked();
});

for (const language of ["en", "ja"] as const) {
  test(`live pen speed choices work and fit the ${language} phone panel`, async ({
    page,
  }, testInfo) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await signIn(page, `live-speed-${language}`, "en");
    if (language === "ja") {
      await openSettings(page, "en");
      await chooseLanguage(page, "en", "ja");
      await page.getByRole("button", { name: say(stickerBoard.statBoard.flipBack, "ja") }).click();
    }
    await page.getByRole("button", { name: drawKeyName(language, DAILY_TICKETS_PER_DAY) }).click();
    await expect(
      page.getByText(say(stickerCreation.timer.note.startsWhenYouDraw, language)).first(),
    ).toBeVisible();
    const smoothing = page.getByRole("button", {
      name: say(stickerCreation.tools.smoothing, language),
      exact: true,
    });
    await smoothing.click();
    const choices = page.getByRole("combobox", {
      name: say(stickerCreation.smoothingBar.penSpeed, language),
    });
    await expect(choices).toHaveValue("fixed");
    const panel = page.locator(".smoothing-bar");
    for (const mode of ["slow", "fast"] as const) {
      await choices.selectOption(mode);
      await expect(choices).toHaveValue(mode);
      await expect(
        page.getByText(say(stickerCreation.smoothingBar[`${mode}Help`], language)),
      ).toBeVisible();
      const box = await panel.boundingBox();
      if (!box) throw new Error("The smoothing panel is not visible");
      const choiceBox = await choices.boundingBox();
      if (!choiceBox) throw new Error("The speed choices are not visible");
      expect(choiceBox.height).toBeGreaterThanOrEqual(44);
      expect(box.x).toBeGreaterThanOrEqual(0);
      expect(box.x + box.width).toBeLessThanOrEqual(390);
      expect(box.y + box.height).toBeLessThanOrEqual(844);
      expect(await panel.evaluate((element) => element.scrollWidth <= element.clientWidth)).toBe(
        true,
      );
      await page.screenshot({
        path: testInfo.outputPath(`live-speed-${language}-${mode}.png`),
      });
    }
    await page
      .getByRole("slider", {
        name: say(stickerCreation.tools.smoothing, language),
        exact: true,
      })
      .fill("20");
    await smoothing.click();
    const sheet = canvas(page, language);
    await sheet.hover();
    const box = await sheet.boundingBox();
    if (!box) throw new Error("The sheet is not visible");
    await penStroke(page, await pencil(page), along(box, 0.5, 0.2, 0.8), () => 0.5);
    await expect(
      page.getByRole("button", { name: say(stickerCreation.history.undo, language) }),
    ).toBeEnabled();
    await smoothing.click();
    await expect(choices).toHaveValue("fast");
  });
}

test("Japanese post correction controls fit the phone panel", async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await signIn(page, "post-correction-ja", "en");
  await openSettings(page, "en");
  await chooseLanguage(page, "en", "ja");
  await page.getByRole("button", { name: say(stickerBoard.statBoard.flipBack, "ja") }).click();
  await page.getByRole("button", { name: drawKeyName("ja", DAILY_TICKETS_PER_DAY) }).click();
  await expect(
    page.getByText(say(stickerCreation.timer.note.startsWhenYouDraw, "ja")).first(),
  ).toBeVisible();
  await page
    .getByRole("button", { name: say(stickerCreation.tools.smoothing, "ja"), exact: true })
    .click();
  const post = page.getByRole("slider", { name: "後補正", exact: true });
  await expect(post).toHaveValue("0");
  await expect(page.getByRole("switch", { name: "速度による調整" })).toBeDisabled();
  await post.fill("20");
  await expect(page.getByRole("switch", { name: "速度による調整" })).toBeEnabled();
  await expect(page.getByRole("switch", { name: "表示倍率による調整" })).toBeChecked();
  const box = await page.locator(".smoothing-bar").boundingBox();
  if (!box) throw new Error("Post correction panel is not visible");
  expect(box.x).toBeGreaterThanOrEqual(0);
  expect(box.x + box.width).toBeLessThanOrEqual(390);
  expect(box.y + box.height).toBeLessThanOrEqual(844);
  await page.screenshot({
    path: testInfo.outputPath("controls-ja-phone.png"),
  });
});

test("once a pen has drawn here, a palm never draws, and a resting palm doesn't hold up two-finger undo", async ({
  page,
}) => {
  const box = await openSheet(page, "palm");
  const pen = await pencil(page);
  await penStroke(page, pen, along(box, 0.2, 0.1, 0.4), () => 0.5);
  await expect(undo(page)).toBeEnabled();
  // Pencil and finger, so fingers draw: a palm still doesn't.
  await pencilOnlyTile(page).click();
  const fingers = await hand(page);
  const palmRow = along(box, 0.5, 0.55, 0.9);
  await touchStroke(page, fingers, palmRow, PALM_CONTACT_PX);
  expect(await inkAt(page, middle(palmRow))).toBe(0);

  const second = along(box, 0.7, 0.1, 0.4);
  await penStroke(page, pen, second, () => 0.5);
  const palm = { ...at(box, 0.85, 0.95), id: 1, radius: PALM_CONTACT_PX };
  const tap = [at(box, 0.3, 0.85), at(box, 0.45, 0.85)].map((point, i) => ({
    ...point,
    id: 10 + i,
    radius: FINGERTIP,
  }));
  await fingers.down([palm]);
  await fingers.down([palm, ...tap]);
  // The tap lifts; the palm stays down.
  await fingers.up(tap);
  await expect.poll(() => inkAt(page, middle(second))).toBe(0);
  await fingers.up();
});

test("Settings shows Input and Pen pressure once a pen has drawn on the device, and Try it takes the pen", async ({
  page,
}) => {
  await signIn(page, "pencil-settings", language);
  let settings = await openSettings(page, language);
  const { pencil: words } = stickerBoard.settings;
  const input = () => settings.getByRole("radiogroup", { name: say(words.input.title, language) });
  await expect(input()).toHaveCount(0);

  // What a pen's first stroke on the drawing screen keeps on the device.
  await page.evaluate(() => localStorage.setItem("draw.inputMode", "pencilOnly"));
  await page.reload();
  settings = await openSettings(page, language);
  await expect(
    input().getByRole("radio", { name: say(words.input.pencilOnly, language) }),
  ).toBeChecked();
  await settings
    .getByRole("radiogroup", { name: say(words.pressure.title, language) })
    .getByRole("radio", { name: say(words.pressure.light, language) })
    .click();

  const strip = page.locator(".try-pen-pressure__ink");
  await strip.scrollIntoViewIfNeeded();
  const box = await strip.boundingBox();
  if (!box) throw new Error("Try it isn't on screen");
  // Pencil only: a finger leaves the strip blank, and the pen draws.
  const row = along(box, 0.5, 0.1, 0.9);
  await touchStroke(page, await hand(page), row, FINGERTIP);
  expect(await inkedPixels(page, ".try-pen-pressure__ink")).toBe(0);
  await penStroke(page, await pencil(page), row, (i) => 0.1 + (0.9 * i) / row.length);
  expect(await inkedPixels(page, ".try-pen-pressure__ink")).toBeGreaterThan(0);
  // It fades a few seconds after the last stroke, and nothing is kept.
  await expect.poll(() => inkedPixels(page, ".try-pen-pressure__ink"), { timeout: 6000 }).toBe(0);
});
